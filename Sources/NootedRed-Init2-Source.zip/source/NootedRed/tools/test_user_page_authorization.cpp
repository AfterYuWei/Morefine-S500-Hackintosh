#include <UserPageAuthorization.hpp>
#include <cassert>
#include <atomic>
#include <thread>
#include <vector>
#include <cstdio>
using Gate=UserPageAuthorization::Gate<void*,void*,8>;
static void* ptr(unsigned n){return reinterpret_cast<void*>(static_cast<uintptr_t>(n));}
int main(){
 Gate g;assert(!g.permits(nullptr,nullptr));assert(g.enter(nullptr,ptr(1))==Gate::Invalid);
 size_t slots[8];for(unsigned i=0;i<8;i++){slots[i]=g.enter(ptr(100+i),ptr(200+i));assert(slots[i]!=Gate::Invalid);assert(g.permits(ptr(100+i),ptr(200+i)));assert(!g.permits(ptr(100+i),ptr(999)));assert(!g.permits(ptr(999),ptr(200+i)));assert(g.enter(ptr(100+i),ptr(200+i))==Gate::Invalid);}
 assert(g.enter(ptr(900),ptr(901))==Gate::Invalid);
 assert(!g.leave(slots[0],ptr(999),ptr(200)));assert(g.permits(ptr(100),ptr(200)));
 for(unsigned i=0;i<8;i++){assert(g.leave(slots[i],ptr(100+i),ptr(200+i)));assert(!g.permits(ptr(100+i),ptr(200+i)));}
 std::atomic<unsigned> completed{0};std::vector<std::thread> workers;
 for(unsigned i=0;i<8;i++)workers.emplace_back([&,i]{for(unsigned j=0;j<20000;j++){size_t n;do{n=g.enter(ptr(1000+i),ptr(2000+i));}while(n==Gate::Invalid);assert(g.permits(ptr(1000+i),ptr(2000+i)));assert(!g.permits(ptr(1000+i),ptr(9000+i)));assert(g.leave(n,ptr(1000+i),ptr(2000+i)));completed++;}});
 for(auto& t:workers)t.join();assert(completed==160000);for(unsigned i=0;i<8;i++)assert(!g.permits(ptr(1000+i),ptr(2000+i)));
 std::puts("PASS: scoped permits reject foreign process/thread, exhaustion and stale release; 160000 concurrent enter/leave operations");
}
