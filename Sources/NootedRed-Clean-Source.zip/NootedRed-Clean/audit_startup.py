#!/usr/bin/env python3
"""Read-only Mach-O initializer and relocation audit for the local test build."""
import json
from pathlib import Path
import struct
import sys

class MachO:
    def __init__(self, path):
        self.path = Path(path)
        self.data = self.path.read_bytes()
        assert struct.unpack_from('<I', self.data)[0] == 0xfeedfacf
        self.sections, self.segments, self.symbols = [], [], {}
        off = 32
        for _ in range(struct.unpack_from('<I', self.data, 16)[0]):
            cmd, size = struct.unpack_from('<II', self.data, off)
            if cmd == 0x19:
                seg = struct.unpack_from('<II16sQQQQiiII', self.data, off)
                self.segments.append(seg)
                for i in range(seg[9]):
                    v = struct.unpack_from('<16s16sQQIIIIIIII', self.data, off+72+i*80)
                    self.sections.append({'name':v[0].rstrip(b'\0').decode(), 'segment':v[1].rstrip(b'\0').decode(), 'addr':v[2], 'size':v[3], 'offset':v[4], 'reloc_offset':v[6], 'reloc_count':v[7]})
            elif cmd == 2:
                _,_,symoff,nsyms,stroff,strsize = struct.unpack_from('<IIIIII', self.data, off)
                for i in range(nsyms):
                    name, typ, sect, desc, value = struct.unpack_from('<IBBHQ', self.data, symoff+16*i)
                    end = self.data.find(b'\0',stroff+name)
                    self.symbols[self.data[stroff+name:end].decode()] = {'value':value,'type':typ,'section':sect, 'index':i}
            elif cmd == 0xb:
                self.dysym = struct.unpack_from('<20I',self.data,off)
            elif cmd == 0x1b:
                self.uuid_offset = off+8
            off += size
        self.init = next(s for s in self.sections if s['name']=='__mod_init_func')
        self.pointers = list(struct.unpack_from('<'+'Q'*(self.init['size']//8),self.data,self.init['offset']))
    def names(self, value):
        return [n for n,s in self.symbols.items() if s['value']==value and s['section']]
    def local_relocations(self):
        result=[]
        for i in range(self.dysym[19]):
            address, descriptor=struct.unpack_from('<II',self.data,self.dysym[18]+8*i)
            result.append((address,descriptor))
        return result
    def report(self):
        relocs=dict(self.local_relocations())
        return [{'index':i,'value':hex(v),'names':self.names(v), 'relocation':hex(relocs.get(self.init['addr']+8*i,0))} for i,v in enumerate(self.pointers)]

if __name__=='__main__':
    m=MachO(sys.argv[1])
    print(json.dumps(m.report(),indent=2))
