#!/usr/bin/env python3
"""Build the pinned local diagnostic driver, without installing developer tools.

Set CLANG and SDKROOT to an Apple Clang compiler and macOS SDK. Sources must be
present under source/{NootedRed,Lilu,MacKernelSDK}. No root privileges are used.
"""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'kernel-build'
OUT.mkdir(exist_ok=True)
CLANG = os.environ.get('CLANG') or shutil.which('clang')
SDK = os.environ.get('SDKROOT')
if not CLANG or not SDK:
    sys.exit('Set CLANG and SDKROOT before building.')
NR = ROOT / 'source/NootedRed'
LILU = ROOT / 'source/Lilu'
MK = ROOT / 'source/MacKernelSDK'
COMMON = [CLANG, '-arch', 'x86_64', '-mkernel', '-fno-common',
          '-fstack-protector-strong', '-mno-red-zone', '-fno-builtin',
          '-fno-asynchronous-unwind-tables', '-mmacosx-version-min=10.14',
          '-O3', '-Wall', '-Wextra', '-Wno-unused-parameter', '-Wno-c23-extensions',
          '-isysroot', SDK, '-DKERNEL=1', '-DKERNEL_PRIVATE=1',
          '-DPRODUCT_NAME=NootedRed', '-DMODULE_VERSION=0.9.0',
          '-I', str(NR / 'NootedRed'), '-I', str(LILU / 'Lilu'),
          '-I', str(MK / 'Headers')]
CPP = ['-std=c++23', '-fapple-kext', '-fno-rtti', '-fno-exceptions',
       '-fvisibility=hidden', '-fvisibility-inlines-hidden']
# Explicit source list excludes generated test harnesses and backup files.
sources = sorted((NR / 'NootedRed').rglob('*.cpp'))
sources.append(LILU / 'Lilu/Library/plugin_start.cpp')
# Mach-O non-LTO links do not globally sort constructor priority across objects.
# KernelVersion must initialize before hardware singletons read it.
sources.sort(key=lambda p: p.name != 'KernelVersion.cpp')
assert len(sources) == 25, sources
commands = [COMMON + CPP + ['-c', str(p), '-o', str(OUT / (p.stem + '.o'))]
            for p in sources]

def run(command):
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=60)
    return {'command': command, 'returncode': result.returncode,
            'diagnostics': result.stdout + result.stderr}

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(run, commands))
(ROOT / 'compile-commands.json').write_text(json.dumps(commands, indent=2))
(ROOT / 'kernel-compile-results.json').write_text(json.dumps(results, indent=2))
if any(r['returncode'] for r in results):
    for r in results:
        if r['returncode']: print(r['diagnostics'])
    sys.exit(1)

metadata = OUT / 'NootedRed_vers.c'
metadata.write_text('''#include <mach/mach_types.h>
#include <mach/kmod.h>
extern kern_return_t _start(kmod_info_t *, void *);
extern kern_return_t _stop(kmod_info_t *, void *);
extern kern_return_t NootedRed_kern_start(kmod_info_t *, void *);
extern kern_return_t NootedRed_kern_stop(kmod_info_t *, void *);
KMOD_EXPLICIT_DECL(org.ChefKiss.NootedRed, "0.9.0", _start, _stop)
__attribute__((visibility("hidden"))) kmod_start_func_t *_realmain = NootedRed_kern_start;
__attribute__((visibility("hidden"))) kmod_stop_func_t *_antimain = NootedRed_kern_stop;
''')
metadata_command = COMMON + ['-c', str(metadata), '-o', str(OUT / 'NootedRed_vers.o')]
result = run(metadata_command)
(ROOT / 'metadata-compile-result.json').write_text(json.dumps(result, indent=2))
if result['returncode']: sys.exit(result['diagnostics'])
link = [CLANG, '-arch', 'x86_64', '-mkernel', '-nostdlib',
        '-mmacosx-version-min=10.14', '-Wl,-kext', '-Wl,-static']
link += [str(OUT / (p.stem + '.o')) for p in sources]
link += [str(OUT / 'NootedRed_vers.o'), '-L', str(MK / 'Library/x86_64'),
         '-lkmod', '-o', str(OUT / 'NootedRed')]
(ROOT / 'link-command.json').write_text(json.dumps(link, indent=2))
result = run(link)
(ROOT / 'link-result.json').write_text(json.dumps(result, indent=2))
if result['returncode']: sys.exit(result['diagnostics'])
from audit_startup import MachO
linked = MachO(OUT / 'NootedRed')
version_init = linked.symbols['__ZL32_GLOBAL_initCurrentKernelVersionv']['value']
if linked.pointers[0] != version_init:
    sys.exit('Invalid constructor order: KernelVersion must be first.')
import plistlib
analysis_results = []
for target in ('NRed.cpp', 'X5000.cpp'):
    source = next(p for p in sources if p.name == target)
    output = OUT / (source.stem + '-analysis.plist')
    analysis = COMMON + CPP + ['--analyze', str(source), '-o', str(output)]
    result = run(analysis)
    analysis_results.append(result)
    if result['returncode']: sys.exit(result['diagnostics'])
    findings = plistlib.loads(output.read_bytes()).get('diagnostics', [])
    if findings: sys.exit(f'Static analyzer reported {len(findings)} findings.')
(ROOT / 'static-analysis-result.json').write_text(json.dumps(analysis_results, indent=2))
binary = OUT / 'NootedRed'
print(f'PASS: {len(sources)} C++ objects + module metadata; linked MH_KEXT_BUNDLE; static analyzer 0 findings')
print(f'Binary SHA256: {hashlib.sha256(binary.read_bytes()).hexdigest()}')
