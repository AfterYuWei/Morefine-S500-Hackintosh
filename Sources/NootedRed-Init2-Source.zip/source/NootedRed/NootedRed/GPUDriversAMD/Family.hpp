// AMD GPU ASIC families
//
// Copyright © 2024-2025 ChefKiss. Licensed under the Thou Shalt Not Profit License version 1.5.
// See LICENSE for details.

#pragma once
#include <IOKit/IOTypes.h>

constexpr UInt32 AMD_FAMILY_RAVEN = 0x8E;
constexpr UInt32 AMD_FAMILY_NAVI  = 0x8F;
