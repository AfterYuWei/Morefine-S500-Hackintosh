// A short-lived, exact process/thread permit for the kernel signing API.
#pragma once
#include <stddef.h>

namespace UserPageAuthorization {
template <typename Process, typename Thread, size_t Capacity = 8>
class Gate {
    struct Slot { Thread thread{}; Process process{}; };
    Slot slots[Capacity]{};
public:
    static constexpr size_t Invalid = Capacity;
    bool permits(Process process, Thread thread) const {
        if (!process || !thread) { return false; }
        for (size_t i = 0; i < Capacity; ++i) {
            if (__atomic_load_n(&slots[i].thread, __ATOMIC_ACQUIRE) == thread
                && __atomic_load_n(&slots[i].process, __ATOMIC_ACQUIRE) == process) { return true; }
        }
        return false;
    }
    size_t enter(Process process, Thread thread) {
        if (!process || !thread || permits(process, thread)) { return Invalid; }
        for (size_t i = 0; i < Capacity; ++i) {
            Thread empty{};
            if (__atomic_compare_exchange_n(&slots[i].thread, &empty, thread, false,
                                             __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE)) {
                __atomic_store_n(&slots[i].process, process, __ATOMIC_RELEASE);
                return i;
            }
        }
        return Invalid;
    }
    bool leave(size_t index, Process process, Thread thread) {
        if (index >= Capacity || !process || !thread
            || __atomic_load_n(&slots[index].thread, __ATOMIC_ACQUIRE) != thread
            || __atomic_load_n(&slots[index].process, __ATOMIC_ACQUIRE) != process) { return false; }
        __atomic_store_n(&slots[index].process, Process{}, __ATOMIC_RELEASE);
        __atomic_store_n(&slots[index].thread, Thread{}, __ATOMIC_RELEASE);
        return true;
    }
};
}
