#!/usr/bin/env python3
"""Package the clean core from its pinned template; no EFI installation."""
from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
bundle=ROOT/'build-package/NootedRed-Tahoe.kext';c=bundle/'Contents';(c/'MacOS').mkdir(parents=True,exist_ok=True)
shutil.copyfile(ROOT/'kernel-build/NootedRed',c/'MacOS/NootedRed')
shutil.copyfile(ROOT/'bundle-info.plist',c/'Info.plist')
for cmd in [['/usr/bin/codesign','--force','--sign','-','--timestamp=none',str(bundle)],['/usr/bin/codesign','--verify','--deep','--strict','--verbose=2',str(bundle)]]:
    subprocess.run(cmd,check=True,timeout=60)
print(json.dumps({'bundle':str(bundle),'sha256':hashlib.sha256((c/'MacOS/NootedRed').read_bytes()).hexdigest()},indent=2))
