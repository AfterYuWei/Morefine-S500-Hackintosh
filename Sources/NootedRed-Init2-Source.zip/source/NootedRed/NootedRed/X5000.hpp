// AMDRadeonX5000 Patches
//
// Copyright © 2022-2025 ChefKiss. Licensed under the Thou Shalt Not Profit License version 1.5.
// See LICENSE for details.

#pragma once
#include <GPUDriversAMD/Accel/HWAlignManager.hpp>
#include <GPUDriversAMD/Accel/HWDisplay.hpp>
#include <GPUDriversAMD/Accel/HWEngine.hpp>
#include <GPUDriversAMD/AddrLib.hpp>
#include <GPUDriversAMD/FB/FramebufferInfo.hpp>
#include <GPUDriversAMD/FB/SurfaceInfo.hpp>
#include <Headers/kern_patcher.hpp>
#include <IOKit/graphics/IOFramebuffer.h>
#include <PenguinWizardry/ObjectField.hpp>

class X5000
{
    ObjectField<void*>             pm4EngineField;
    ObjectField<void*>             sdma0EngineField;
    ObjectField<UInt32>            supportedDisplayCountField;
    ObjectField<UInt32>            seCountField;
    ObjectField<UInt32>            shCountField;
    ObjectField<UInt32>            hwMaxCUsField;
    ObjectField<bool>              hasUVD0Field;
    ObjectField<bool>              hasVCEField;
    ObjectField<bool>              hasVCN0Field;
    ObjectField<bool>              hasSDMAPagingQueueField;
    ObjectField<bool>              hasGetAllClockLimitsField;
    ObjectField<bool>              dccDisplayableSupportField;
    ObjectField<UInt32>            familyTypeField;
    ObjectField<Gfx9ChipSettings>  chipSettingsField;
    ObjectField<void*>             hwChannelHWInterfaceField;
    ObjectField<mach_vm_address_t> hwChannelSubmitCommandBuffer;
    OSMetaClass*                   pm4EngineMC{nullptr};
    OSMetaClass*                   sdmaEngineMC{nullptr};
    mach_vm_address_t              orgGFX9SetupAndInitializeHWCapabilities{0};
    mach_vm_address_t              orgGetHWChannel{0};
    mach_vm_address_t              orgAdjustVRAMAddress{0};
    mach_vm_address_t              orgObtainAccelChannelGroup{0};
    mach_vm_address_t              orgHwlConvertChipFamily{0};
    mach_vm_address_t              orgPM4SubmitCommandBuffer{0};
    void                           (*notifyGfxAccess)(void*){nullptr};

public:
    static X5000& singleton();

    X5000();

    void processKext(KernelPatcher& patcher, size_t id, mach_vm_address_t slide, size_t size);

private:
    static bool   allocateHWEngines(void* self);
    static void   wrapSetupAndInitializeHWCapabilities(void* self);
    static void*  wrapGetHWChannel(void* self, AMDHWEngineType engineType, UInt32 ringId);
    static void   initializeFamilyType(void* self);
    static void*  allocateAMDHWDisplay(void* self);
    static UInt64 wrapAdjustVRAMAddress(void* self, UInt64 addr);
    static UInt32 returnZero();
    static void*  wrapObtainAccelChannelGroup(void* self, UInt32 priority);
    static void*  wrapObtainAccelChannelGroup1304(void* self, UInt32 priority, void* task);
    static UInt32 wrapHwlConvertChipFamily(void* self, UInt32 family, UInt32 revision);
    static UInt32 computeSubmitCommandBuffer(void* self, void* info);
    static bool   fixedGetDisplayInfo(AMDRadeonX5000_AMDHWDisplay* self, UInt32 fbIndex, bool isCRTEnabled,
                                      bool ignoreCRTOffsetCheck, IOFramebuffer* fb, FramebufferInfo* fbInfo);
    static void   fixedGetSurfaceInfo(AMDRadeonX5000_AMDHWAlignManager* self, AMD_SURFACE_INFO_STRUCT* pStruct);
};
